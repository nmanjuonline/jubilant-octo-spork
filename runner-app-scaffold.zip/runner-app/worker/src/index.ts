// Phase 1 API stub: anonymous Web Push subscriptions + scheduled sender.
// Not part of the Vite build. Add @cloudflare/workers-types and web-push-compatible code when implementing M4.

export default {
  async fetch(req: Request): Promise<Response> {
    const url = new URL(req.url)
    if (url.pathname === '/push/subscribe' && req.method === 'POST') {
      // TODO: validate body, upsert into D1 PushSubscription (endpoint, keys, raceId, raceDate, timezone, prefs)
      return new Response(null, { status: 204 })
    }
    if (url.pathname === '/push/subscribe' && req.method === 'DELETE') {
      // TODO: delete subscription by endpoint
      return new Response(null, { status: 204 })
    }
    return new Response('Not found', { status: 404 })
  },

  async scheduled(): Promise<void> {
    // TODO: select due subscriptions (index on raceDate), send via Web Push (VAPID secrets),
    // delete endpoints that return 404/410, update lastSentAt, cap sends per type/week.
  },
}
