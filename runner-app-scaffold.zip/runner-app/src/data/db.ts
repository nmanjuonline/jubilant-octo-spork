import Dexie, { type Table } from 'dexie'
import type { Logistics, Plan, Poi, Race, Result } from './types'

class RunnerDB extends Dexie {
  races!: Table<Race, string>
  pois!: Table<Poi, string>
  plans!: Table<Plan, string>
  logistics!: Table<Logistics, string>
  results!: Table<Result, string>

  constructor() {
    super('runner-app')
    this.version(1).stores({
      races: 'id, date',
      pois: 'id, raceId',
      plans: 'id, raceId',
      logistics: 'raceId',
      results: 'id, raceId, createdAt',
    })
  }
}

export const db = new RunnerDB()
