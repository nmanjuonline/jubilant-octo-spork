export type Strategy = 'even' | 'negative' | 'custom'
export type PoiType = 'aid_station' | 'toilet' | 'parking' | 'transit' | 'family_spot' | 'medical' | 'finish'

export interface Race {
  id: string
  name: string
  date: string // ISO date
  startTime: string // HH:mm
  distanceKm: number
  city: string
  lat?: number
  lng?: number
  gpx?: string // raw GPX text (or a catalog reference later)
}

export interface Poi {
  id: string
  raceId: string
  type: PoiType
  km: number
  name: string
  lat?: number
  lng?: number
  notes?: string
}

export interface FuelPrefs {
  firstGelMin: number
  gelIntervalMin: number
  waterAtAidStations: boolean
}

export interface Plan {
  id: string
  raceId: string
  goalTimeSec: number
  strategy: Strategy
  negativeSplitPct: number // e.g. 0.02 = 2%
  customSplitsSec?: number[]
  fuel: FuelPrefs
}

export interface Logistics {
  raceId: string
  bib?: string
  corral?: string
  startTime?: string
  parkingNote?: string
  transitNote?: string
  checked: string[] // ids of ticked checklist items
}

export interface Result {
  id: string
  raceId: string
  finishTimeSec: number
  splitsSec?: number[]
  bib?: string
  createdAt: string
}
