const pad = (n: number) => String(n).padStart(2, '0')

/** 3725 -> "1:02:05", 305 -> "5:05" */
export function formatTime(totalSec: number): string {
  const s = Math.max(0, Math.round(totalSec))
  const h = Math.floor(s / 3600)
  const m = Math.floor((s % 3600) / 60)
  const sec = s % 60
  return h > 0 ? `${h}:${pad(m)}:${pad(sec)}` : `${m}:${pad(sec)}`
}

/** seconds per km -> "5:30 /km" */
export const formatPace = (secPerKm: number) => `${formatTime(secPerKm)} /km`
