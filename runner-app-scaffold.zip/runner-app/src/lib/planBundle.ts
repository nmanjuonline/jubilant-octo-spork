import type { Logistics, Plan, Poi, Race } from '../data/types'

export interface PlanBundle {
  version: 1
  race: Race
  plan: Plan
  logistics?: Logistics
  pois: Poi[]
  exportedAt: string
}

/** URL-safe base64 of the bundle JSON, for share links (#fragment is never sent to a server). */
export function toFragment(bundle: PlanBundle): string {
  const bytes = new TextEncoder().encode(JSON.stringify(bundle))
  let bin = ''
  bytes.forEach((b) => (bin += String.fromCharCode(b)))
  return btoa(bin).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '')
}

export function fromFragment(fragment: string): PlanBundle {
  const b64 = fragment.replace(/-/g, '+').replace(/_/g, '/')
  const bin = atob(b64)
  const bytes = Uint8Array.from(bin, (c) => c.charCodeAt(0))
  const bundle = JSON.parse(new TextDecoder().decode(bytes)) as PlanBundle
  if (bundle.version !== 1) throw new Error('Unsupported plan version')
  return bundle
}
// TODO: add compression (CompressionStream) and QR code rendering for the desktop -> phone handoff.
