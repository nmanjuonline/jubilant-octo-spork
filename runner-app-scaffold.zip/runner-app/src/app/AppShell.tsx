import { NavLink, Outlet } from 'react-router-dom'

const links = [
  { to: '/', label: 'Home', end: true },
  { to: '/plan', label: 'Plan' },
  { to: '/course', label: 'Course' },
  { to: '/race-morning', label: 'Race day' },
  { to: '/results', label: 'Results' },
  { to: '/settings', label: 'Settings' },
]

/** Bottom tab bar on phones, left side nav from 1024px (see global.css). */
export default function AppShell() {
  return (
    <div className="shell">
      <nav className="nav" aria-label="Main">
        {links.map((l) => (
          <NavLink key={l.to} to={l.to} end={l.end}>{l.label}</NavLink>
        ))}
      </nav>
      <main className="main"><Outlet /></main>
    </div>
  )
}
