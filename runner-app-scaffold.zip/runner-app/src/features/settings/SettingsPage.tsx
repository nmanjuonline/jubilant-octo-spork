export default function SettingsPage() {
  return (
    <section>
      <h1>Settings</h1>
      {/* TODO: units (km/mi), notification toggles (Web Push), export/import PlanBundle (src/lib/planBundle.ts) */}
      <p className="muted">Units, notifications, and data export will live here.</p>
    </section>
  )
}
