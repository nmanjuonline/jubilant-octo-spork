export default function ResultsPage() {
  return (
    <section>
      <h1>Results</h1>
      <p className="muted">Add a result after your race to build your PR history.</p>
      {/* TODO: result form, shareable result card (html-to-image), PR history from db.results, finish photos */}
    </section>
  )
}
