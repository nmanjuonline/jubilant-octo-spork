export interface Forecast {
  tempC: number
  rainProbPct: number
  windKmh: number
}

export function gearFor(f: Forecast): string[] {
  const gear = ['Bib and safety pins', 'Race-tested shoes', 'Watch charged']
  if (f.tempC < 8) gear.push('Gloves', 'Throwaway warm layer')
  if (f.tempC > 25) gear.push('Sunscreen', 'Cap', 'Extra hydration plan')
  if (f.rainProbPct > 30) gear.push('Cap or visor', 'Poncho for the start pen')
  if (f.windKmh > 25) gear.push('Windproof layer')
  return gear
}
