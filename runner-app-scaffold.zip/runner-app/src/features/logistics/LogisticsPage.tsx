import { gearFor } from './gearRules'

// Placeholder forecast; replace with Open-Meteo (via a Worker proxy) for the race location and start time.
const sample = { tempC: 6, rainProbPct: 40, windKmh: 12 }

export default function LogisticsPage() {
  return (
    <section>
      <h1>Race morning</h1>
      <h2>Gear checklist</h2>
      <ul>{gearFor(sample).map((g) => <li key={g}>{g}</li>)}</ul>
      {/* TODO: bib, corral, start time, parking/transit notes, countdown, persisted checklist ticks */}
    </section>
  )
}
