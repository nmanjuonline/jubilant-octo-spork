import { Link } from 'react-router-dom'

export default function HomePage() {
  return (
    <section>
      <h1>Your next race</h1>
      <p className="muted">No race yet. Start with a plan, then add your course.</p>
      <p><Link to="/plan">Plan your pacing</Link></p>
      {/* TODO: upcoming race card from db.races, past results */}
    </section>
  )
}
