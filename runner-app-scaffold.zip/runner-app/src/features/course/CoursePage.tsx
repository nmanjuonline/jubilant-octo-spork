import { useMemo, useState, type ChangeEvent } from 'react'
import { Area, AreaChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { kmGradients } from './difficulty'
import { parseGpx, type TrackPoint } from './gpx'

export default function CoursePage() {
  const [pts, setPts] = useState<TrackPoint[]>([])
  const [error, setError] = useState('')

  async function onFile(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    if (!file) return
    try {
      setPts(parseGpx(await file.text()))
      setError('')
    } catch (err) {
      setPts([])
      setError(err instanceof Error ? err.message : 'Could not read this file.')
    }
  }

  const chartData = useMemo(() => {
    const step = Math.max(1, Math.ceil(pts.length / 500))
    return pts.filter((_, i) => i % step === 0).map((p) => ({ km: +(p.distM / 1000).toFixed(2), ele: Math.round(p.ele) }))
  }, [pts])
  const kms = useMemo(() => (pts.length ? kmGradients(pts) : []), [pts])

  return (
    <section>
      <h1>Course</h1>
      <label className="file">Upload course (GPX)
        <input type="file" accept=".gpx,application/gpx+xml,text/xml" onChange={onFile} />
      </label>
      {error && <p role="alert" className="error">{error}</p>}
      {!pts.length && !error && <p className="muted">Upload a GPX file to see the elevation profile and difficulty per km.</p>}
      {pts.length > 0 && (
        <>
          <div className="chart">
            <ResponsiveContainer width="100%" height={240}>
              <AreaChart data={chartData}>
                <XAxis dataKey="km" unit=" km" />
                <YAxis domain={['dataMin - 5', 'dataMax + 5']} unit=" m" width={56} />
                <Tooltip />
                <Area dataKey="ele" stroke="var(--accent)" fill="var(--accent-soft)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
          <ul className="strip" aria-label="Difficulty per km">
            {kms.map((k) => (
              <li key={k.km} className={`band-${k.band}`} title={`Km ${k.km}: ${k.gradientPct.toFixed(1)}% (${k.band})`}>
                {k.km}
              </li>
            ))}
          </ul>
        </>
      )}
      {/* TODO: map (MapLibre/Leaflet), POI list + map markers, family-spot ETA (needs Plan) */}
    </section>
  )
}
