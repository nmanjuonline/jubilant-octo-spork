import type { TrackPoint } from './gpx'

export type Band = 'downhill' | 'easy' | 'moderate' | 'hard' | 'very-hard'

/** Suggested bands from the spec; keep configurable. */
export function bandFor(gradientPct: number): Band {
  if (gradientPct < -3) return 'downhill'
  if (gradientPct < 1) return 'easy'
  if (gradientPct < 3) return 'moderate'
  if (gradientPct <= 6) return 'hard'
  return 'very-hard'
}

function eleAt(pts: TrackPoint[], d: number): number {
  if (d <= 0) return pts[0].ele
  for (let i = 1; i < pts.length; i++) {
    if (pts[i].distM >= d) {
      const a = pts[i - 1]
      const b = pts[i]
      const span = b.distM - a.distM || 1
      return a.ele + ((b.ele - a.ele) * (d - a.distM)) / span
    }
  }
  return pts[pts.length - 1].ele
}

export interface KmDifficulty {
  km: number // 1-based
  gradientPct: number
  band: Band
}

export function kmGradients(pts: TrackPoint[]): KmDifficulty[] {
  const total = pts[pts.length - 1].distM
  const out: KmDifficulty[] = []
  for (let k = 0; k * 1000 < total; k++) {
    const start = k * 1000
    const end = Math.min(start + 1000, total)
    const gradientPct = end > start ? ((eleAt(pts, end) - eleAt(pts, start)) / (end - start)) * 100 : 0
    out.push({ km: k + 1, gradientPct, band: bandFor(gradientPct) })
  }
  return out
}
