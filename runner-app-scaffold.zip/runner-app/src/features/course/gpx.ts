export interface TrackPoint {
  lat: number
  lng: number
  ele: number
  distM: number // cumulative distance from start
}

const R = 6371000
const rad = (d: number) => (d * Math.PI) / 180

function haversine(a: { lat: number; lng: number }, b: { lat: number; lng: number }): number {
  const dLat = rad(b.lat - a.lat)
  const dLng = rad(b.lng - a.lng)
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(rad(a.lat)) * Math.cos(rad(b.lat)) * Math.sin(dLng / 2) ** 2
  return 2 * R * Math.asin(Math.sqrt(h))
}

/** Moving average over a distance window to tame noisy GPS elevation. */
export function smoothElevation(pts: TrackPoint[], windowM: number): TrackPoint[] {
  const half = windowM / 2
  let lo = 0
  let hi = 0
  let sum = 0
  return pts.map((p) => {
    while (hi < pts.length && pts[hi].distM <= p.distM + half) sum += pts[hi++].ele
    while (pts[lo].distM < p.distM - half) sum -= pts[lo++].ele
    return { ...p, ele: sum / (hi - lo) }
  })
}

export function parseGpx(xml: string, smoothingM = 75): TrackPoint[] {
  const doc = new DOMParser().parseFromString(xml, 'application/xml')
  if (doc.querySelector('parsererror')) throw new Error('This file is not valid GPX.')
  const nodes = Array.from(doc.getElementsByTagName('trkpt'))
  if (nodes.length < 2) throw new Error('No track points found in this GPX file.')

  let dist = 0
  const pts: TrackPoint[] = nodes.map((n, i) => {
    const lat = +n.getAttribute('lat')!
    const lng = +n.getAttribute('lon')!
    const ele = +(n.getElementsByTagName('ele')[0]?.textContent ?? 0)
    if (i > 0) {
      const prev = nodes[i - 1]
      dist += haversine(
        { lat: +prev.getAttribute('lat')!, lng: +prev.getAttribute('lon')! },
        { lat, lng },
      )
    }
    return { lat, lng, ele, distM: dist }
  })
  return smoothElevation(pts, smoothingM)
}
// TODO: move parsing into a Web Worker for very large files (50k+ points).
