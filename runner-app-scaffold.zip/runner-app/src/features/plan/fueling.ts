import type { FuelPrefs } from '../../data/types'
import { segments } from './pace'

export interface FuelEvent {
  atSec: number
  km: number
  kind: 'gel' | 'water'
  note: string
}

export function kmAtTime(splits: number[], segs: number[], t: number): number {
  let elapsed = 0
  let km = 0
  for (let i = 0; i < splits.length; i++) {
    if (t <= elapsed + splits[i]) return km + segs[i] * ((t - elapsed) / splits[i])
    elapsed += splits[i]
    km += segs[i]
  }
  return km
}

export function timeAtKm(splits: number[], segs: number[], targetKm: number): number {
  let elapsed = 0
  let km = 0
  for (let i = 0; i < splits.length; i++) {
    if (targetKm <= km + segs[i]) return elapsed + splits[i] * ((targetKm - km) / segs[i])
    elapsed += splits[i]
    km += segs[i]
  }
  return elapsed
}

/** Defaults are editable by the runner. General guidance only, not nutrition advice. */
export function buildFuelSchedule(
  splits: number[],
  distanceKm: number,
  aidStationKms: number[],
  prefs: FuelPrefs,
): FuelEvent[] {
  const segs = segments(distanceKm)
  const total = splits.reduce((a, b) => a + b, 0)
  const events: FuelEvent[] = []

  for (let t = prefs.firstGelMin * 60; t < total - 600; t += prefs.gelIntervalMin * 60) {
    events.push({ atSec: t, km: kmAtTime(splits, segs, t), kind: 'gel', note: 'Take a gel' })
  }
  if (prefs.waterAtAidStations) {
    for (const km of aidStationKms) {
      events.push({ atSec: timeAtKm(splits, segs, km), km, kind: 'water', note: 'Aid station: water' })
    }
  }
  return events.sort((a, b) => a.atSec - b.atSec)
}
