import { describe, expect, it } from 'vitest'
import { buildSplits, cumulative, segments } from './pace'

const sum = (a: number[]) => a.reduce((x, y) => x + y, 0)

describe('buildSplits', () => {
  it('even pace: 10K in 50:00 gives 5:00 per km', () => {
    const s = buildSplits(10, 3000)
    expect(s).toHaveLength(10)
    expect(new Set(s)).toEqual(new Set([300]))
  })

  it('always sums exactly to the goal time', () => {
    for (const strategy of ['even', 'negative'] as const) {
      expect(sum(buildSplits(21.0975, 6000 + 7, strategy))).toBe(6007)
    }
  })

  it('handles a partial final segment', () => {
    expect(segments(21.0975).at(-1)).toBeCloseTo(0.0975)
  })

  it('negative split makes the second half faster', () => {
    const s = buildSplits(10, 3000, 'negative', 0.03)
    expect(sum(s.slice(5))).toBeLessThan(sum(s.slice(0, 5)))
    expect(cumulative(s).at(-1)).toBe(3000)
  })
})
