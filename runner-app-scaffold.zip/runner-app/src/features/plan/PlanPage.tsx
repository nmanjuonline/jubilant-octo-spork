import { useMemo, useState } from 'react'
import type { Strategy } from '../../data/types'
import { formatTime } from '../../lib/format'
import { buildSplits, cumulative, segments } from './pace'

export default function PlanPage() {
  const [distance, setDistance] = useState(10)
  const [goalMin, setGoalMin] = useState(55)
  const [strategy, setStrategy] = useState<Strategy>('even')

  const splits = useMemo(() => buildSplits(distance, goalMin * 60, strategy), [distance, goalMin, strategy])
  const cum = cumulative(splits)
  const segs = segments(distance)

  return (
    <section>
      <h1>Race-day plan</h1>
      <div className="form-row">
        <label>Distance (km)
          <input type="number" min={1} step={0.1} value={distance} onChange={(e) => setDistance(+e.target.value)} />
        </label>
        <label>Goal time (minutes)
          <input type="number" min={1} value={goalMin} onChange={(e) => setGoalMin(+e.target.value)} />
        </label>
        <label>Strategy
          <select value={strategy} onChange={(e) => setStrategy(e.target.value as Strategy)}>
            <option value="even">Even pace</option>
            <option value="negative">Negative split</option>
          </select>
        </label>
      </div>
      <div className="table-scroll">
        <table>
          <thead><tr><th>Km</th><th>Split</th><th>Total</th></tr></thead>
          <tbody>
            {splits.map((s, i) => (
              <tr key={i}>
                <td>{segs[i] === 1 ? i + 1 : distance}</td>
                <td>{formatTime(s)}</td>
                <td>{formatTime(cum[i])}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {/* TODO: fueling schedule (see fueling.ts), custom split editing, save plan to db, km/mile toggle */}
    </section>
  )
}
