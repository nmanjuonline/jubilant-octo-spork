import type { Strategy } from '../../data/types'

/** Segment lengths in km: [1,1,...,remainder]. 10 -> ten 1s; 21.0975 -> twenty-one 1s + 0.0975 */
export function segments(distanceKm: number): number[] {
  const full = Math.floor(distanceKm)
  const rem = +(distanceKm - full).toFixed(4)
  const segs: number[] = Array(full).fill(1)
  if (rem > 0) segs.push(rem)
  return segs
}

/** Per-segment times in whole seconds that always sum exactly to goalSec. */
export function buildSplits(
  distanceKm: number,
  goalSec: number,
  strategy: Strategy = 'even',
  negativePct = 0.02,
  custom?: number[],
): number[] {
  const segs = segments(distanceKm)
  if (!segs.length) return []
  if (strategy === 'custom' && custom?.length === segs.length) return custom

  let start = 0
  const raw = segs.map((len) => {
    const factor = strategy === 'negative' ? (start < distanceKm / 2 ? 1 + negativePct : 1 - negativePct) : 1
    start += len
    return len * factor
  })
  const total = raw.reduce((a, b) => a + b, 0)
  const splits = raw.map((r) => Math.round((r / total) * goalSec))
  splits[splits.length - 1] += goalSec - splits.reduce((a, b) => a + b, 0)
  return splits
}

export const cumulative = (splits: number[]) =>
  splits.reduce<number[]>((acc, v) => [...acc, (acc.at(-1) ?? 0) + v], [])
